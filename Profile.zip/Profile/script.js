 document.getElementById("form").addEventListener("submit",function(e){
        e.preventDefault();
        let name = document.getElementById("name").value;
        let mail = document.getElementById("email").value;
           let msg = document.getElementById("message").value;
        if(name==="" || mail==="" || msg===""){
            alert(" ⚠️ please fill the necessary details");
        }
        else{
            document.getElementById("res").textContent=" ✅ Thank you, "+name+" Your Website looks," +msg;
            document.getElementById("res").style.color="white";
             document.getElementById("res").style.textAlign="center";
             document.getElementById("res").style.fontFamily="arial";
             document.getElementById("res").style.fontWeight="bold";
              document.getElementById("res").style.fontSize="25px";
                 document.getElementById("res").style.backgroundColor="skyblue";
                   document.getElementById("res").style.margin="30px";
                    document.getElementById("res").style.padding="30px";
        }
        });