
    document.getElementById("form").addEventListener("submit",function(e){
        e.preventDefault();
        let uname = document.getElementById("name").value;
        let email = document.getElementById("mail").value;
        let phoneno = document.getElementById("num").value;
        let gen=document.getElementById("gender").value;
        let cour=document.getElementById("course").value;

        let msg = document.getElementById("message").value;
        

        if(uname==="" || email==="" || phoneno==="" || msg==="" || gen=="" || cour==""){
            alert(" ⚠️ please fill the necessary details");
        }
        else{
           alert("All the details are filled successfully")
        }
        });
  
