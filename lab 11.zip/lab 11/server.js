const express=require('express');

const app = express();//create the application
app.use(express.static('public'));

app.listen(4800,() =>{ //listen has given
    console.log("Server is running on http://localhost:4800");
});