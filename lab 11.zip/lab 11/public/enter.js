 document.getElementById("form").addEventListener("submit",function(e){
         e.preventDefault();
          let name = document.getElementById("name").value;
        let ename = document.getElementById("event").value;
          let edate = document.getElementById("date").value;
            let des = document.getElementById("prayer").value;
             const validEvents = [
        "Sunday Service",
        "Revival for Youth",
        "Praise Fasting Prayer",
        "Communion Service",
        "Praise Night Prayer"
    ];

    // Validation
    if (name === "" || ename === "" || edate === "" || des === "") {
        alert("⚠️ Please enter all the necessary details");
    } 
    else if (ename==validEvents) {
        alert("✅ Your event name has been correctly registered");
        alert("✅ Your documents have been successfully registered");
    } 
    else {
        alert("⚠️ Please enter a correct event name");
    }
});